package com.demolearn.springbootdemo.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demolearn.springbootdemo.configs.Result;
import com.demolearn.springbootdemo.mapper.AdminMapper;
import com.demolearn.springbootdemo.mapper.HomeWorkMapper;
import com.demolearn.springbootdemo.pojo.Admin;
import com.demolearn.springbootdemo.pojo.HomeWork;
import com.demolearn.springbootdemo.pojo.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

//这是老师发布作业以及评分的接口
@RestController
@RequestMapping("/homework")
public class HomeWorkController {

    @Autowired
    HomeWorkMapper homeWorkMapper;

    //新增新闻
    @PostMapping
    //@RequestBody就是把前台传过来的json数据转换成Java对象
    public Result save(@RequestBody HomeWork work){
        work.setTime(new Date()); //为插入新闻实体时设置时间（它会自动转格式）
        homeWorkMapper.insert(work);
        return Result.success();
    }

    //删除新闻，根据id删除
    @DeleteMapping("/{id}")
    //@PathVariable就是把前台通过{id}占位符传过来的数据解析成Long类型的id值
    public Result delete(@PathVariable Long id){
        homeWorkMapper.deleteById(id);
        return Result.success();
    }

    //更新新闻，即访问/user即可
    @PutMapping
    //@RequestBody就是把前台传过来的json数据转换成Java对象
    public Result update(@RequestBody HomeWork work){
        homeWorkMapper.updateById(work);
        return Result.success();
    }

    //查询方法
    @GetMapping
    public List<HomeWork> load(){
        //查询所有，不设置查询条件，则返回所有
        List<HomeWork> homeWorkList = homeWorkMapper.selectList(null);
        return homeWorkList;
    }

}
