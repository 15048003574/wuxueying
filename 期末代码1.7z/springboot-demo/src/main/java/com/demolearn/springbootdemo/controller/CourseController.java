package com.demolearn.springbootdemo.controller;


import com.demolearn.springbootdemo.configs.Result;
import com.demolearn.springbootdemo.mapper.CourseMapper;
import com.demolearn.springbootdemo.pojo.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/course")
public class CourseController {
    //自动注入属性
    @Autowired
    private CourseMapper courseMapper;


    //新增方法
    @PutMapping
    public Result update(@RequestBody Course course){
        courseMapper.updateById(course);
        return Result.success();
    }

    //删除，根据id删除
    @DeleteMapping("/{id}")
    //@PathVariable就是把前台通过{id}占位符传过来的数据解析成Long类型的id值
    public Result delete(@PathVariable Long id){
        courseMapper.deleteById(id);
        return Result.success();
    }

    //查询方法
    @GetMapping
    public List<Course> load(){
        //查询所有，不设置查询条件，则返回所有
        List<Course> courseList = courseMapper.selectList(null);
        return courseList;
    }

}
