package com.demolearn.springbootdemo.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demolearn.springbootdemo.configs.Result;
import com.demolearn.springbootdemo.mapper.CourseMapper;
import com.demolearn.springbootdemo.mapper.SCresMapper;
import com.demolearn.springbootdemo.pojo.Course;
import com.demolearn.springbootdemo.pojo.SCres;
import com.demolearn.springbootdemo.pojo.Student;
import com.demolearn.springbootdemo.pojo.Teacher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/scres")
public class SCresController {
    //自动注入属性
    @Autowired
    private SCresMapper sCresMapper;


    //删除，根据id删除
    @DeleteMapping("/{id}")
    //@PathVariable就是把前台通过{id}占位符传过来的数据解析成Long类型的id值
    public Result delete(@PathVariable Long id){
        int i = sCresMapper.deleteById(id);
        if(i == 0) return Result.error("-1","您还未选过本课嗷~");
        return Result.success();
    }

    //更新方法
    @PutMapping
    public Result update(@RequestBody SCres res){
        sCresMapper.updateById(res);
        return Result.success();
    }

    //查询特定学生的课表的方法
    @PostMapping
    public List<SCres> load(@RequestBody Student student){
        //将当前登录的学生传递过来，按学生名进行查找返回即可
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq("stuname",student.getName());
        List<SCres> sCresList = sCresMapper.selectList(wrapper);
        System.out.println(sCresList);
        return sCresList;
    }

    //查询特定老师对学生打分的方法
    @PostMapping("/score")
    public List<SCres> score(@RequestBody Teacher teacher){
        //将当前登录的老师传递过来，按老师名进行查找返回即可
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq("teachername",teacher.getName());
        List<SCres> sCresList = sCresMapper.selectList(wrapper);
        System.out.println(sCresList);
        return sCresList;
    }

}
