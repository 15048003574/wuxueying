package com.demolearn.springbootdemo.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@TableName("teacher")
@Data
public class Teacher {
    @TableId(type = IdType.AUTO) //让该id自然增加
    private Integer id;
    private String name;
    private String password;
    private String college;
    private String role;
}
