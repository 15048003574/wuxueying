package com.demolearn.springbootdemo.pojo;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@TableName("student") //让其与数据库中的表对应起来，必须要写
@Data
public class Student {
    @TableId(type = IdType.AUTO) //让该id自然增加
    private Integer id;
    private String name;
    private String password;
    private String sex;
    private String major;
    private String college;
    private String role;
}
