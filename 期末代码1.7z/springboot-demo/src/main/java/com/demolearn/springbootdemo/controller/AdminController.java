package com.demolearn.springbootdemo.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demolearn.springbootdemo.configs.Result;
import com.demolearn.springbootdemo.mapper.AdminMapper;
import com.demolearn.springbootdemo.pojo.Admin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    AdminMapper adminMapper;

    //管理员登录方法
    @PostMapping("/login")
    public Result<Admin> login(@RequestBody Admin admin){
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq("name",admin.getName()); //比对姓名
        wrapper.eq("password",admin.getPassword()); //比对密码
        Admin res = adminMapper.selectOne(wrapper); //查询结果
        if(res == null) return Result.error("-1","您不是管理员嗷~");
        else return Result.success(res);
    }
}
