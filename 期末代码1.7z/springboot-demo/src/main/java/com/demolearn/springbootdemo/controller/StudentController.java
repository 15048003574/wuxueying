package com.demolearn.springbootdemo.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demolearn.springbootdemo.configs.Result;
import com.demolearn.springbootdemo.mapper.CourseMapper;
import com.demolearn.springbootdemo.mapper.SCresMapper;
import com.demolearn.springbootdemo.mapper.StudentMapper;
import com.demolearn.springbootdemo.pojo.Course;
import com.demolearn.springbootdemo.pojo.SCres;
import com.demolearn.springbootdemo.pojo.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {
    //自动注入学生属性
    @Autowired
    private StudentMapper studentMapper;

    //自动注入课程属性
    @Autowired
    private CourseMapper courseMapper;

    //自动注入选课结果属性
    @Autowired
    private SCresMapper scresMapper;

    //选课方法第一步
    public static Integer scId = null; //用来记录这个课程id
    @PostMapping("/form")
    public Result select(@RequestBody Course course){
        //插入之前先判断这个课是否已经被选过了，防止数据库中有null值数据出现
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq("id",course.getId());
        List<SCres> a = scresMapper.selectList(wrapper);
        if(a.size() == 1)  return Result.error("-1","来晚啦，它已经被选走了嗷~");
        //将选择的课程传过来，然后将结果集中所有值都赋一遍值，再存进数据库中
        SCres s = new SCres();
        scId = course.getId();
        s.setId(course.getId());
        s.setName(course.getName());
        s.setWeek(course.getWeek());
        s.setTime(course.getTime());
        s.setTeachername(course.getTeachername());
        //执行插入操作
        scresMapper.insert(s);
        return Result.success();
    }
    //选课方法第二步
    @PostMapping("/user")
    public Result user(@RequestBody Student student){
        //接收学生的信息
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq("id",scId);
        List<SCres> s = scresMapper.selectList(wrapper);
        if(s.size() > 1)  return Result.error("-1","来晚啦，它已经被选走了嗷~");
        SCres a = scresMapper.selectById(scId);
        a.setScore("0");
        a.setStuname(student.getName());
        scresMapper.updateById(a);
        return Result.success();
    }


    //登录方法
    @PostMapping("/login")
    public Result login(@RequestBody Student student){

        //查找Student表中是否有对应的name的，有则成功，否则失败
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq("name",student.getName());
        wrapper.eq("password",student.getPassword());
        Student res = studentMapper.selectOne(wrapper);
        if(res == null) return Result.error("-1","学生不存在");
        else return Result.success(res);
    }

    //注册方法
    @PostMapping("/register")
    public Result Register(@RequestBody Student student){
        //如果没有注册过，则予以注册
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq("name",student.getName());
        wrapper.eq("password",student.getPassword());
        Student res = studentMapper.selectOne(wrapper);
        //没有查到，予以注册,插入数据库
        if(res == null){
            studentMapper.insert(student);
            return Result.success();
        }else {
            return Result.error("-1","该用户已注册！");
        }
    }

    //更新方法
    @PutMapping
    public Result update(@RequestBody Student student){
        studentMapper.updateById(student);
        return Result.success();
    }

    //删除用户，根据id删除
    @DeleteMapping("/{id}")
    //@PathVariable就是把前台通过{id}占位符传过来的数据解析成Long类型的id值
    public Result delete(@PathVariable Long id){
        studentMapper.deleteById(id);
        return Result.success();
    }

    //查询方法
    @GetMapping
    public List<Student> load(){
        //查询所有，不设置查询条件，则返回所有
        List<Student> studentList = studentMapper.selectList(null);
        return studentList;
    }



}
