package com.demolearn.springbootdemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demolearn.springbootdemo.pojo.Admin;
import com.demolearn.springbootdemo.pojo.HomeWork;
import org.springframework.stereotype.Component;

@Component
public interface HomeWorkMapper extends BaseMapper<HomeWork> {
}
