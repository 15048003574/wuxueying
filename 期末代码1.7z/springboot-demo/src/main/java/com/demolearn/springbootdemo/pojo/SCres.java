package com.demolearn.springbootdemo.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

//学生和课程联合表
@TableName("scres")
@Data
public class SCres {
    private Integer id;
    private String name;
    private String week;
    private String time;
    private String teachername;
    private String stuname;
    private String score;
}
