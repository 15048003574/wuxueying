package com.demolearn.springbootdemo.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.demolearn.springbootdemo.configs.Result;
import com.demolearn.springbootdemo.mapper.CourseMapper;
import com.demolearn.springbootdemo.mapper.StudentMapper;
import com.demolearn.springbootdemo.mapper.TeacherMapper;
import com.demolearn.springbootdemo.pojo.Course;
import com.demolearn.springbootdemo.pojo.Student;
import com.demolearn.springbootdemo.pojo.Teacher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/teacher")
public class TeacherController {
    //自动注入属性
    @Autowired
    private TeacherMapper teacherMapper;

    //课程属性，因为要查询课程表
    @Autowired
    private CourseMapper courseMapper;

    //登录方法
    @PostMapping("/login")
    public Result login(@RequestBody Teacher teacher){

        //查找Student表中是否有对应的name的，有则成功，否则失败
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq("name",teacher.getName());
        wrapper.eq("password",teacher.getPassword());
        Teacher res = teacherMapper.selectOne(wrapper);
        if(res == null) return Result.error("-1","教师不存在");
        else return Result.success(res);
    }

    //注册方法
    @PostMapping("/register")
    public Result Register(@RequestBody Teacher teacher){
        //如果没有注册过，则予以注册
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq("name",teacher.getName());
        wrapper.eq("password",teacher.getPassword());
        Teacher res = teacherMapper.selectOne(wrapper);
        //没有查到，予以注册,插入数据库
        if(res == null){
            teacherMapper.insert(teacher);
            return Result.success();
        }else {
            return Result.error("-1","该用户已注册！");
        }
    }

    //新增方法
    @PutMapping
    public Result update(@RequestBody Teacher teacher){
        teacherMapper.updateById(teacher);
        return Result.success();
    }

    //删除用户，根据id删除
    @DeleteMapping("/{id}")
    //@PathVariable就是把前台通过{id}占位符传过来的数据解析成Long类型的id值
    public Result delete(@PathVariable Long id){
        teacherMapper.deleteById(id);
        return Result.success();
    }

    //查询方法
    @GetMapping
    public List<Teacher> load(){
        //查询所有，不设置查询条件，则返回所有
        List<Teacher> studentList = teacherMapper.selectList(null);
        return studentList;
    }

    //教师查看自己课表方法
    @PostMapping("/course")
    public List<Course> course(@RequestBody Teacher teacher){
        //查询所有，不设置查询条件，则返回所有
        QueryWrapper wrapper = new QueryWrapper();
        wrapper.eq("teachername",teacher.getName());
        List<Course> studentList = courseMapper.selectList(wrapper);
        return studentList;
    }

}
