package com.demolearn.springbootdemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demolearn.springbootdemo.pojo.Course;
import com.demolearn.springbootdemo.pojo.Teacher;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

@Mapper
@Component
public interface TeacherMapper extends BaseMapper<Teacher> {
}
